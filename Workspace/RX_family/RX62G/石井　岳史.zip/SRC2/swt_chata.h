#ifndef SWT_CHATA_H

#define SWT_CHATA_H


int chata_down ( int swt, int i );

#endif

