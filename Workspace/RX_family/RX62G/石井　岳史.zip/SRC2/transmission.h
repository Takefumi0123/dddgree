#ifndef TRANSMISSION_H

#define TRANSMISSION_H
#include "iodefine.h"

void transimission( char *s );

#endif